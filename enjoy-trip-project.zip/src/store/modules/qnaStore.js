const qnaStore = {
  namespaced: true,
  state: {},
  getters: {},
  mutations: {},
  actions: {},
};

export default qnaStore;
