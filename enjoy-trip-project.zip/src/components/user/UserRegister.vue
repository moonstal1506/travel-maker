<template>
  <b-container class="bv-example-row mt-3">
    <b-row>
      <b-col>
        <b-alert variant="secondary" show><h3>회원가입</h3></b-alert>
      </b-col>
    </b-row>
  </b-container>
</template>

<script>
export default {
  name: "UserRegister",
};
</script>

<style></style>
